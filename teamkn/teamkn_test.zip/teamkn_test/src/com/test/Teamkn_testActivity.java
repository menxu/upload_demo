package com.test;


import com.test.adpater.ListAdapter;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

public class Teamkn_testActivity extends Activity {
	static // �Ի���
	 LinearLayout comment_frame_linearLayout;
	 ImageView emotion_icn_smile;
	 ImageView emotion_icn_wink;
	 ImageView emotion_icn_gasp;
	 ImageView emotion_icn_sad;
	 ImageView emotion_icn_heart;
	
    private ListView listView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        listView = (ListView)findViewById(R.id.list_show);
       
        String [] data=new String[]{"��ɮ","�����","���˽�","ɳ����","��������","������ʦ","��ʴ��","��ĸ����","�׹Ǿ�","���þ�"};
        ListAdapter adapter = new ListAdapter(this,data);
        
        listView.setAdapter(adapter);
        
        comment_frame_linearLayout=(LinearLayout)findViewById(R.id.comment_frame_linearLayout);
	    emotion_icn_smile = (ImageView)this.findViewById(R.id.emotion_icn_smile);
	    emotion_icn_wink = (ImageView)this.findViewById(R.id.emotion_icn_wink);
	    emotion_icn_gasp = (ImageView)this.findViewById(R.id.emotion_icn_gasp);
	    emotion_icn_sad = (ImageView)this.findViewById(R.id.emotion_icn_sad);
	    emotion_icn_heart = (ImageView)this.findViewById(R.id.emotion_icn_heart);
        
	    listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				System.out.println("listView.setOnItemClickListener   " +  arg3);
			}
		});
        listView.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				System.out.println("listView.setOnTouchListener " + event.getX() + "  :  " + event.getY());
				if(event.getY()>250 && event.getY()<300){
					AnimationSet dialog_set_animation = new AnimationSet(false);
		    		dialog_set_animation.setDuration(500);
		    		// ������ʧ
		    		Animation dialog_set_alpha_animation = new AlphaAnimation(1.0f, 0.0f);
		    		dialog_set_alpha_animation.setFillAfter(true);
		    		Animation dialog_set_translate_animation=new TranslateAnimation(10, 10, 20, 20+50); 
		    		dialog_set_alpha_animation.setFillAfter(true);
		    		dialog_set_animation.addAnimation( dialog_set_alpha_animation);
		    		dialog_set_animation.addAnimation(dialog_set_translate_animation);
		    		dialog_set_animation.setStartOffset(500); 
		    		
		    		comment_frame_linearLayout.setAnimation(dialog_set_animation); 
		    		dialog_set_animation.startNow();
		    		
		    		comment_frame_linearLayout.setVisibility(View.GONE);
				}
				return false;
			}
		});
    }
	public static  void showDialog(float x, float y) {
		System.out.println("@@@@@@@@@@@@@ x:y --- "  + x  + " :  " + y);
		
		comment_frame_linearLayout.setVisibility(View.VISIBLE);
		Animation animation = new TranslateAnimation(10,10,y,y);
		animation.setFillAfter(true);
		comment_frame_linearLayout.startAnimation(animation);	
	}
	
	
    @Override
    public boolean onTouchEvent(MotionEvent event) {
    	int x = (int) event.getX();
    	int y = (int) event.getY();
    	System.out.println("onTouchEvent x : y" + x + " : " + y);
    	if( y >200 && y<100){
    		System.out.println("public boolean onTouchEvent(MotionEvent event) { x : y" + x + " : " + y);
    		AnimationSet dialog_set_animation = new AnimationSet(false);
    		dialog_set_animation.setDuration(50);
    		// ������ʧ
    		Animation dialog_set_alpha_animation = new AlphaAnimation(1.0f, 0.0f);
    		dialog_set_alpha_animation.setFillAfter(true);
    		Animation dialog_set_translate_animation=new TranslateAnimation(x, x, y, y+50); 
    		dialog_set_alpha_animation.setFillAfter(true);
    		dialog_set_animation.addAnimation( dialog_set_alpha_animation);
    		dialog_set_animation.addAnimation(dialog_set_translate_animation);
    		dialog_set_animation.setStartOffset(10); 
    		
    		comment_frame_linearLayout.setAnimation(dialog_set_animation); 
    		dialog_set_animation.startNow();
    	}
    	return super.onTouchEvent(event);
    }
    
}