package com.test.adpater;

import com.test.R;
import com.test.Teamkn_testActivity;
import com.test.R.layout;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

public class ListAdapter extends BaseAdapter{
	Context context;
	String[] data;
	public ListAdapter(Context context, String[] data) {
		this.context = context;
		this.data = data;
	}
	@Override
	public int getCount() {
		return data.length;
	}

	@Override
	public Object getItem(int position) {
		return data[position];
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		 View view = convertView;
		if(view==null){
			view = LayoutInflater.from(context).inflate( R.layout.list_item_show, null);	
		}
		TextView textView = (TextView) view.findViewById(R.id.list_item_tv);
		textView.setText(data[position]);
		ImageButton button = (ImageButton) view.findViewById(R.id.list_item_bt);
		
		
		button.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:				
					break;
				case MotionEvent.ACTION_MOVE:
					break;
				case MotionEvent.ACTION_UP:
					System.out.println(" -----  " + event.getX() + "  :  " + event.getY());
					Teamkn_testActivity.showDialog(event.getX(),event.getY());
					
//					 new AlertDialog.Builder(context)   
//				        .setTitle("��Ʒ���飺")   
//				        .setMessage("detail")                 
//				        .setPositiveButton("ȷ��", null)   
//				        .show();
					
					break;
				default:
					break;
				}
				return false;
			}
		});
		return view;
	}  
}




//������һ������ı���
//for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
//                        View listItem = listAdapter.getView(i, null, listView);
//                        listItem.measure(0, 0); // ��������View �Ŀ���
//                        int list_child_item_height = listItem.getMeasuredHeight()+listView.getDividerHeight();
//                        Log.w("ListView Child Height", ">>> child height="+list_child_item_height);
//                        totalHeight += list_child_item_height; // ͳ������������ܸ߶�
//                }
