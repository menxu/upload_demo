package com.test.animation;

import android.content.Context;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class DialogAnimation {
	Context context;
	
	 // �Ի���
	 LinearLayout comment_frame_linearLayout;
	 ImageView emotion_icn_smile;
	 ImageView emotion_icn_wink;
	 ImageView emotion_icn_gasp;
	 ImageView emotion_icn_sad;
	 ImageView emotion_icn_heart;
	 
	 Animation smile_scale_animation;
	 Animation wink_scale_animation;
	 Animation gasp_scale_animation;
	 Animation sad_scale_animation;
	 Animation heart_scale_animation;
		
	//Animation dialog_set_animation;
	 Animation dialog_set_alpha_animation;
	 Animation dialog_set_translate_animation;
	 AnimationSet dialog_set_animation = new AnimationSet(false);
     
	 Animation dialog_from_animation;
	 
	private   void load_animation(int x ,int y){
		
		dialog_from_animation = new TranslateAnimation(x, x, y, y);
		smile_scale_animation.setFillAfter(true);
		
		//�����ڲ����ֵ���״
		smile_scale_animation =new ScaleAnimation(x, x, y, y,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		smile_scale_animation.setFillAfter(true);
		smile_scale_animation.setStartOffset(10);
		
		wink_scale_animation = new ScaleAnimation(x, x, y, y,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		wink_scale_animation.setFillAfter(true);
		wink_scale_animation.setStartOffset(20);
		
		gasp_scale_animation = new ScaleAnimation(x, x, y, y,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		gasp_scale_animation.setFillAfter(true);
		gasp_scale_animation.setStartOffset(30);
		
		sad_scale_animation = new ScaleAnimation(x, x, y, y,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		sad_scale_animation.setFillAfter(true);
		sad_scale_animation.setStartOffset(40);
		
		heart_scale_animation =new ScaleAnimation(x, x, y, y,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		heart_scale_animation.setFillAfter(true);
		heart_scale_animation.setStartOffset(50);
		
		// ������ʧ
		dialog_set_alpha_animation = new AlphaAnimation(1.0f, 0.0f);
		dialog_set_translate_animation=new TranslateAnimation(x, x, y, y+50); 
		dialog_set_animation.addAnimation( dialog_set_alpha_animation);
		dialog_set_animation.addAnimation(dialog_set_translate_animation);
		dialog_set_animation.setStartOffset(10); 
		
		// �������
	   
	}
	private void startAnimation(){
		comment_frame_linearLayout.startAnimation(dialog_from_animation);
		
		emotion_icn_smile.startAnimation(smile_scale_animation);				
		emotion_icn_wink.startAnimation(wink_scale_animation);
		emotion_icn_gasp.startAnimation(gasp_scale_animation);
		emotion_icn_sad.startAnimation(sad_scale_animation);
		emotion_icn_heart.startAnimation(heart_scale_animation);		
	}
	private void endAnimation(){
		// ������ʧ
		comment_frame_linearLayout.setAnimation(dialog_set_animation); 
		dialog_set_animation.startNow();
	}
}
